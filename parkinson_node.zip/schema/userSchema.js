var mongoose = require("mongoose")
var Schema = mongoose.Schema

var userSchema = new Schema({
    firstName: { 
        type: String,
        require: true
    },
    lastName: {
        type: String
    },
    email: {
        type: String,
        unique:true
    },
    contact: {
        type: String
    },
    password:{
        type: String
    },
    status:{
        type:String
    }
}, { strict: false },)

var users = mongoose.model("user", userSchema)
module.exports = users