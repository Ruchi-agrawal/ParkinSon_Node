const userSchema = require("../schema/userSchema")
const { encryptPassword, decryptPassword } = require('../utility/pwdHashing');
const { generateToken } = require("../config/auth")
const statusMessages = require("../config/appConstants")
/**
 * 
 * @param {body of data} req 
 * @param {statusMessages} res 
 * Get one user
 */
const loginUser = async (req, res) => {
    let { email, password } = req.body
    try {
        await findUser(email, async (response) => {
            const email = req.body.email.toLowerCase();
            let token;
            if (response && response.email) {
                const { _id, role, firstName, lastName, countryCode } = response
                const hash = response.password
                const result = await decryptPassword(password, hash)
                token = await generateToken(email, _id, role)
                if (result === true && token !== '') {
                    let data = { email: email, id: _id, token: token, userType: role, firstName, lastName, countryCode }
                    statusMessages.SUCCESS_MSG.SUCCESS.data = data
                    res.json(statusMessages.SUCCESS_MSG.SUCCESS);
                }
                else {
                    res.json(statusMessages.ERROR_MSG.PWD_NOT_MATCH);
                }
            }
            else {
                res.json(statusMessages.ERROR_MSG.EMAIL_NOT_FOUND);
            }
        });
    }
    catch (error) {
        statusMessages.ERROR_MSG.IMP_ERROR.error = error
        res.json(statusMessages.ERROR_MSG.IMP_ERROR);
    }
}

const findUser = async (email, callback) => {
    try {
        const response = await userSchema.findOne({ email: email })
        if (response) {
            callback(response);
        } else {
            callback(false);
        }
    }
    catch (error) {
        throw error
    }
}

module.exports = {
    loginUser
}